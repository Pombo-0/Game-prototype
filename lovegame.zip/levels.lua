function level1(func, dt)
if func == "load" then
    for i=1, 3 do
        table.insert(enemyList, Enemy())
    
elseif func == "update" then
    
    
elseif func == "draw" then
    
    
end

end
