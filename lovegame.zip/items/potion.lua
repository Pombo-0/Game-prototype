Potion = Object:extend()
local healthp = love.graphics.newImage("images/health_potion.png")

function Potion:new(tipo, x, y)
    self.tipo = tipo 
    self.x = x 
    self.y = y 
    
    if tipo == "health" then 
        self.image = healthp
    elseif tipo == "mana" then 
        self.image = manap
    end
    
    self.HITBOX = HC.rectangle(self.x, self.y, 25, 25)
    
end

function Potion:update(dt)
    self.HITBOX:moveTo(self.x, self.y)
end

function Potion:draw()
    --self.HITBOX:draw('fill')
    love.graphics.draw(self.image, self.x, self.y, 0, 3, 3, 4, 4)
end