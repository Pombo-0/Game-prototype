Player = Object:extend()
lgp = love.graphics.print
 axeChecker = false
 bowChecker = 0
 axeCharge = 0
 bowCharge = 0
 color = {0,1,0}
power = 1
playerDamaged = 0


damageSound = love.audio.newSource("sounds/damage.mp3", "static")
deathSound = love.audio.newSource("sounds/chipotle.mp3", "static")

function Player:new()
    self.angle = meialua
    self.image = love.graphics.newImage("images/player.png")
    self.x = 400 --window_width/2 
    self.y = 400 --window_height/2 
    self.speed = 200
    self.width = 32--500--self.image:getWidth()*50
    self.height=32
    self.hp = 150
    
    self.origin_x = self.width / 2
    self.origin_y = self.height / 2
    
    --self.hands = Hands("blue", self)
    self.WEAPON = "sword"
    tipo = 1
    self.weapon = {}
    self.project = {}
    
    self.isEnemy = false 
    
    self.immunity = 0
    self.HITBOX = HC.rectangle(self.x, self.y, 30, 40)
    self.color = {1, 1, 1}
    self.alpha = 0.5
    weaponChange = 1
end

function Player:update(dt)
    self.HITBOX:moveTo(self.x, self.y)
    
-- WEAPONS DELAY & RELOAD
    if weaponChange > 2 then 
        weaponChange = 1
    end
    for k, v in pairs(touches) do
    if tocando(bshoot, v) then
        if self.WEAPON=="bow" then
            if bowChecker>1 then
            self.weapon[1].attacking=1
                if bowCharge<1 then
                    bowCharge=round(bowCharge+0.7*dt, 2)
                end
            else
            bowChecker=bowChecker+10*dt --MUDAR PRA 2.25
            end
        elseif self.WEAPON=="axe" then
            tick.delay(function() axeChecker = true end, 0.25)
            if axeChecker then
                if axeCharge<1 then
            axeCharge=round(axeCharge+0.7*dt, 2)
                end
            end
        end
        else
            axeChecker = false
            bowChecker=0
    end 
    
    if tocando (change, v) then 
        if weaponChange < 3 then
        self.WEAPON = weaponList[weaponChange]
        weaponChange = weaponChange + 1
        end
    end 
    
     
    
    end
    
    
--WINDOW COLLISION--
    if true then 
    if self.x < window_limitx then
        self.x = window_limitx
    elseif self.x + self.width > window_width then
       self.x = window_width - self.width
    end
    if self.y < window_limitx then
      self.y = window_limitx
    elseif self.y + self.height > window_height then
       self.y = window_height - self.height
    end 
    end 
    
---WEAPONS--
    if #self.weapon < 1 then
        if self.WEAPON=="sword" then
            table.insert(self.weapon, Sword(self, tipo))
        elseif self.WEAPON=="bow" then
            table.insert(self.weapon, Bow(self))
        elseif self.WEAPON=="hammer" then
            table.insert(self.weapon, Hammer(self))
        elseif self.WEAPON=="axe" then
            table.insert(self.weapon, Axe(self, tipo))
        end
    end
    if #self.weapon > 1 then
        table.remove(self.weapon, 2)
    end
    self.weapon[1]:update(dt)
    --self.hands:update(dt)
    for i,v in ipairs(self.project) do
        v:update(dt)
        if v.dead then
            table.remove(self.project, i)
        end
    end 
    
    
    
---COLLISION & DAMAGE--
    if playerDamaged == 1 and self.immunity < 1 then 
        self.immunity = self.immunity + dt 
        self.color[2] = self.color[2] + dt*3
        self.color[3] = self.color[3] + dt*3
        self.alpha = self.alpha - dt
        
    end
    if self.immunity >=1 then 
        playerDamaged = 0
        self.immunity = 0
        self.alpha = 0.5
    end 
    if self.color[2] <= 0 or self.color[3] <= 0 or self.alpha <= 0 then  
        self.isDamaged = 0
        self.color[2] = 1
        self.color[3] = 1
        --self.alpha = 1
    end
    
    for i, v in ipairs(enemyList) do
        if (v.WEAPON=="sword" and self.HITBOX:collidesWith(v.weapon.HITBOX) and self.immunity == 0 and v.isDamaging) then 
            self.hp = self.hp - 20
            self.color = {1, 0, 0}
            playerDamaged = 1
            damageSound:play()
        end 
        for j, w in ipairs(v.project) do
            if self.HITBOX:collidesWith(w.HITBOX) and self.immunity == 0 then 
                self.hp = self.hp - 20
                playerDamaged = 1
                table.remove(v.project, j)
                self.color = {1, 0, 0}
                damageSound:play()
            end
        end
    end 
    
    for i, v in ipairs(potionList) do
        if self.HITBOX:collidesWith(v.HITBOX) then
            table.remove(potionList, i)
            self.hp = self.hp + 20
        end 
    end 
    
    --DT = dt
    
--!function end:
end

function Player:draw()
    --self.HITBOX:draw('line')
    
    love.graphics.setColor(self.color)
    love.graphics.draw(self.image, self.x, self.y, 0, 4, 4, 4, 4) --self.origin_x, self.origin_y)
    love.graphics.setColor(1, 1, 1) 
    
    
    
    
    --lgp("attacking: " .. self.weapon[1].attacking, self.x - 400, self.y - 150)
    for i,v in ipairs(self.project) do
        v:draw()
    end
    
    self.weapon[1]:draw()
    
    --self.hands:draw()
    --love.graphics.print("balas: " .. #self.project, self.x, self.y + 75)
    --love.graphics.print("origin_x: "..self.weapon[1].origin_x.." / origin_y: "..self.weapon[1].origin_y, self.x-400, self.y)
    if self.WEAPON=="axe"then
    love.graphics.print("shooting: "..self.weapon[1].shooting, self.x-200, self.y)
    end
    --lgp("axeCharge: "..axeCharge, self.x-400, self.y-130)
    --lgp("projeteis: "..#self.project,self.x-400,self.y-110)
    
    if axeCharge ~= 0 then
        love.graphics.rectangle("line", self.x-40, self.y-40, 75, 10)
        if color[1]<=1 then
            color[1]=color[1]+0.0350
        else
            color[2]=color[2]-0.0350
        end
        love.graphics.setColor(color)
        love.graphics.rectangle("fill", self.x-39.5, self.y-40, 73.5*axeCharge, 10)
        love.graphics.setColor(1,1,1)
    else
            color={0,1,0}
    end
    
    if bowCharge ~= 0 then
        for i=1, 4 do
            love.graphics.rectangle("line", (self.x+45)-(20*i), self.y-40, 7.5,7.5)
            if bowCharge >= 0.25*i then
                power = i
                love.graphics.rectangle("fill", (self.x+45)-(20*i), self.y-40, 7.5,7.5)
            end
        end
    end
    --if power~=nil then lgp(power, self.x+50, self.y+150) end
   -- lgp("bowChecker: "..bowChecker, self.x+60, self.y+170)
   
    --lgp(self.weapon[1].attacking, self.x+100, self.y)
    --lgp("axeChecker: "..tostring(axeChecker), self.x+100, self.y)
    --lgp("axeCharge: "..axeCharge, self.x+100, self.y+50)
    
end






function Player:keyPressed(key)
    if key == "4" then
    if self.WEAPON=="sword" then
            if self.weapon[1].attacking==0 then
            tick.delay(function ()
                self.weapon[1].attacking=1
                end, 0.05)
            :after(function () self.weapon[1].attacking=0 end, 0.5) 
            end
    elseif self.WEAPON=="hammer" then
            if self.weapon[1].attacking==0 then
            tick.delay(function ()
                self.weapon[1].attacking=1
                end, 0.05)
            :after(function () self.weapon[1].attacking=0 end, 0.5) 
            end
    elseif self.WEAPON=="axe" then
            if self.weapon[1].attacking==0 then
            tick.delay(function ()
                self.weapon[1].attacking=1
                end, 0.05)
            :after(function () self.weapon[1].attacking=0 end, 0.5)
            end
    end
    
    elseif key=="5" then
        if tipo>3 then tipo = 1 end
        tipo = tipo + 1
    end
end

function Player:keyReleased(key)
    if key == "4" then
        if self.WEAPON=="bow" then
            if bowChecker>1 then
        self.weapon[1].attacking = 0
        table.insert(self.project, Arrow(self, 350*power))
        --self.hands.right.origin_x=self.weapon[1].lastoriginx
        --self.hands.right.origin_y=self.weapon[1].lastoriginy
        
        --self.hands.left.origin_x=self.weapon[1].lastoriginx
        --self.hands.left.origin_y=self.weapon[1].lastoriginy
        power = 1
            end
        elseif self.WEAPON=="axe" then
            if axeCharge>=1 then
                self.weapon.shooting=1
                    if self.weapon.shooting == 1 then
                    self.weapon.shooting=0
                    --self.weapon.attacking=0
                    --if self.ammo == 1 then
                        --self.ammo=0
                        --if #self.project==0 then
                        table.insert(self.project, axeProject(self, 500))
                        tick.delay(function()
                            table.remove(self.project, 1) end, 1.25)
                        --end
                    --end
                end
            end
            axeCharge=0
        end
        bowCharge=0
    end
end







----REPOSITORIO
function BOTOES_DE_ANDAR()
    if false then
    if tocando(left, v) then
        self.x = self.x - self.speed * dt
        self.angle = meialua*2
    end
    if tocando(right, v) then
        self.x = self.x + self.speed * dt
        self.angle = meialua*4
    end
    if tocando(up, v) then
        self.y = self.y - self.speed * dt
        self.angle = -meialua
    end
    if tocando(down, v) then
        self.y = self.y + self.speed * dt
        self.angle = meialua
    end 
    end 
    if tocando(left, v) and tocando(up, v) then
        self.angle=-meialua*1.5
    elseif tocando(left, v) and tocando(down, v) then
        self.angle=meialua*1.5
    elseif tocando(right, v) and tocando(up, v) then
        self.angle=meialua*3.5
    elseif tocando(right, v) and tocando(down, v) then
        self.angle=-meialua*3.5
    end
    
end