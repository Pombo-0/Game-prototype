sexo = "nao ta tocando o jogador"
tela = "nao ta tocando a TELA"


touches = {}

function toque_update()
    
    --if tocando(player) then 
        --sexo = "ta tocando o jogador"
    --else
        --sexo = "nao ta tocando o jogador" 
    --end 
    
end

function toque_draw()
    lgp("q. de toques: "..howManyTouches(), 300, 300)
    lgp(sexo, 300, 350)
    lgp(tela, 300, 400)
    
    for k, v in pairs(touches) do 
        lgp(v[1], 300, 500)
        lgp(v[2], 350, 500)
        
    end
end

-------------------------------

function love.touchpressed(id, x, y)
    if canTouch then
    touches[id]={x, y, height = 0, width = 0}
    
    
    tela = "ta tocando a TELA"
    
    
    for k, v in pairs(touches) do 
        if not canTouch then break end
    if tocando(bshoot, v) then
    if player.WEAPON=="sword" then
            if player.weapon[1].attacking==0 then 
                player.isDamaging = true
            tick.delay(
                function ()
                    player.isDamaging = false
                end, 0.005
                )
            tick.delay(function ()
                player.weapon[1].attacking=1
                end, 0.05)
            :after(function () player.weapon[1].attacking=0 end, 0.5) --MUDAR ESSE TEMPO PRA 0.5
            end
    elseif player.WEAPON=="hammer" then
            if player.weapon[1].attacking==0 then
            tick.delay(function ()
                player.weapon[1].attacking=1
                end, 0.05)
            :after(function () player.weapon[1].attacking=0 end, 0.5) 
            end
    elseif player.WEAPON=="axe" then
            if player.weapon[1].attacking==0 then
            tick.delay(function ()
                player.weapon[1].attacking=1
                end, 0.05)
            :after(function () player.weapon[1].attacking=0 end, 0.5)
            end
    end 
    end 
     
    
    if false and tocando (change, v) then 
        if weaponChange <= 3 then 
        table.remove(player.weapon, 1)
        weaponChange = weaponChange + 1
        player.WEAPON = playerWeapons[weaponChange]
        
        end
    end
     
    end -- FOR END
    end -- if false end
end

function love.touchmoved(id, x, y)
    if canTouch then 
        
    touches[id][1] = x
    touches[id][2] = y
    
    --touches[id].x = x
    --touches[id].x = y
    
    lgp(x, 400, 435)
    lgp(y, 400, 470)
    
    tela = "ta tocando a TELA"
    
    end 
end

function love.touchreleased(id, x, y)
    if canTouch then 
        
    tela = "nao ta tocando a TELA"
    
    for k, v in pairs(touches) do 
        if not canTouch then break end
            if tocando(bshoot, v) then
        if player.WEAPON=="bow" then
            if bowChecker>1 then
        player.weapon[1].attacking = 0
        table.insert(player.project, Arrow(player, 350*power))
        
        power = 1
            end
        elseif player.WEAPON=="axe" then
            if axeCharge>=1 then
                player.weapon.shooting=1
                    if player.weapon.shooting == 1 then
                    player.weapon.shooting=0
                    --player.weapon.attacking=0
                    --if player.ammo == 1 then
                        --player.ammo=0
                        --if #player.project==0 then
                        table.insert(player.project, axeProject(player, 500))
                        tick.delay(function()
                            table.remove(player.project, 1) end, 1.25)
                        --end
                    --end
                end
            end
            axeCharge=0
            
        end
        bowCharge=0
        bowChecker=0
    end
    end 
    
    touches[id] = nil 
    
    end
end

function howManyTouches()
  local howMany = 0
  for k in pairs(touches) do
    howMany = howMany + 1
  end
  return howMany
end

function tocando(a, b)
    local a_left = a.x
    local a_right = a.x + a.width
    local a_top = a.y
    local a_bottom = a.y + a.height
    
    --for k, v in pairs(touches) do
        return  a_right > b[1]
        and a_left < b[1]
        and a_bottom > b[2]
        and a_top < b[2]
    --end 
end







-------------------------------
--REPOSITORIO--
-------------------------------
function repositorio()
    if tocando(left) then
        player.x = player.x - player.speed
        player.angle = 180
    end
    if tocando(right) then
        player.x = player.x + player.speed
        player.angle = 0
    end
    if tocando(up) then
        player.y = player.y - player.speed
        player.angle = 90
    end
    if tocando(down) then
        player.y = player.y + player.speed
        player.angle = 270
    end
    
    if tocando(bshoot) then
    
        if player.ammo == 1 then
            player.ammo = 0
        table.insert(listOfBullets, Bullet(player.x, player.y, 700))
        tick.delay(function () player.ammo = 1 end, 1)
        end
    end
    
end