# This repository is no longer maintained

If you do maintain an active fork, please open a PR to add it to this readme.

All other issues reports and pull requests will not be attended.

## General Purpose 2D Collision Detection System

Documentation and examples here: http://hc.readthedocs.org/
