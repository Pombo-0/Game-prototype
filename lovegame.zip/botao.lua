Botao = Object:extend()

function Botao:new(x, y, h, w, image, sx, sy)
    self.x = x
    self.y = y
    self.height = h
    self.width = w 
    if image ~= nil then 
        self.image = love.graphics.newImage(image)
    end 
    self.sx = sx
    self.sy = sy
    
end

function Botao:update(dt)
    
end

function Botao:draw()
    if self.image == nil then 
        love.graphics.rectangle("fill", self.x, self.y, self.height, self.width)
    else 
        love.graphics.draw(self.image, self.x, self.y, 0, self.sx, self.sy)
    end
end