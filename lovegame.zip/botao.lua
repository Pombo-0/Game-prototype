Botao = Object:extend()

function Botao:new(x, y, h, w)
    self.x = x
    self.y = y
    self.height = h
    self.width = w
    
    
    
end

function Botao:update(dt)
    
end

function Botao:draw()
    love.graphics.rectangle("fill", self.x, self.y, self.height, self.width)
    
end