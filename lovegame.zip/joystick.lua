Joystick = Object:extend()

 centerx = 150
 centery = 300
 sera = "isnt touching joystick"

function Joystick:new()
    self.angle = 0
    self.big = {
        x = centerx,
        y = centery,
        r = 170,
        
        
    }
    self.small = {
        x = centerx,
        y = centery,
        r = 40
    }
end 

function Joystick:update(dt)
    if howManyTouches() > 0 then
        for k,v in pairs(touches) do
            if circleCollision(v, self.big) then
                self.small.x = v[1] 
                self.small.y = v[2]
                --player.x = player.x+player.speed*dt*math.cos(self.angcos)
                --player.y = player.y+player.speed*dt*math.sin(self.angsin)
                sera = "is touching joystick"
            else
                sera = "is NOT touching joystick"
            end
        end
    else
        self.small.x = centerx
        self.small.y = centery
        sera = "is NOT touching joystick"
    end
    distancej = getDistance(self.big.x, self.big.y, self.small.x, self.small.y)
    distancex = self.small.x-self.big.x
    distancey = self.small.y-self.big.y
    
    --self.angle = math.acos(distancex/distancej)
    self.angle = math.atan2(distancey, distancex)
    
    self.angcos = math.acos(distancex/distancej)
    self.angsin = math.asin(distancey/distancej)
    
    for k,v in pairs(touches) do
            if circleCollision(v, self.big) then
                player.x = player.x + player.speed*dt*math.cos(self.angcos)
                player.y = player.y + player.speed*dt*math.sin(self.angsin)
                player.angle = self.angle
            end 
    end
    
    --if circleCollision(self.small, self.big) and howManyTouches() > 0 then 
        
            --player.x = player.x+player.speed*dt*math.cos(self.angcos)
            --player.y = player.y+player.speed*dt*math.sin(self.angsin)
            --sera = "is touching joystick"
    --else 
            --sera = "is NOT touching joystick"
    --end
    
end 

function Joystick:draw()
    love.graphics.circle("line", self.big.x, self.big.y, self.big.r-70)
    love.graphics.circle("fill", self.small.x, self.small.y, self.small.r)
    
    
    
end 



function circleCollision(a, c)
    if a.x ~= nil and a.y ~= nil then
        return a.x < c.x + c.r and a.x > c.x- c.r and a.y > c.y - c.r and a.y < c.y + c.r
    else 
        return a[1] < c.x + c.r and a[1] > c.x- c.r and a[2] > c.y - c.r and a[2] < c.y + c.r
    end
    
end 




function repositorio()
   --self.small.x < centerx+self.big.r and self.small.x > centerx-self.big.r and self.small.y > centery-self.big.r and self.small.y < centery+self.big.r

end