--! MUDE O PINTO DE ORIGEM PARA O MEIO DA MAO E APENAS COLOQUE MAIS PRA FRENTE ASSIM FICA MAIS FACIL POR ITENS NAS MAOS

Hands = Object:extend()
    --local de = 7
function Hands:new(color, target)
    if color == "blue" then
        self.image = love.graphics.newImage("images/blue_hand.png")
    elseif color == "red" then
        self.image = love.graphics.newImage("images/red_hand.png")
    elseif color == "green" then
        self.image = love.graphics.newImage("images/green_hand.png")
    elseif color == "purple" then
        self.image = love.graphics.newImage("images/purple_hand.png")
    elseif color == "yellow" then
        self.image = love.graphics.newImage("images/yellow_hand.png")
    end
    self.target = target
    self.right = {}
    self.left = {}
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    self.right.origin_x=32-25
    self.right.origin_y=32-25
    self.left.origin_x=32-25
    self.left.origin_y=32-25
end

function Hands:update(dt)
    self.right.x=self.target.x
    self.right.y=self.target.y
    
    self.left.x=self.target.x
    self.left.y=self.target.y
     
    self.right.x=self.right.x+5
    
    self.angle = self.target.angle
    self.right.angle,self.left.angle=self.angle, self.angle
end

function Hands:draw()
    love.graphics.draw(self.image, self.left.x, self.left.y, self.angle, 1, -1, self.left.origin_x, self.left.origin_y)
    
    love.graphics.draw(self.image, self.right.x, self.right.y, self.angle, 1, 1, self.right.origin_x, self.right.origin_y)
    
end