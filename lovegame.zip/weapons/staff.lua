Staff = Object:extend()

function Staff:new(target)
    self.target = target
    self.image = love.graphics.newImage("images/staff.png")
    
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    self.origin_x = -1
    self.origin_y = 27.5
    
    
end

function Staff:update(dt)
    self.x = self.target.x
    self.y = self.target.y
    self.angle = self.target.angle
    
    
end

function Staff:draw()
    love.graphics.draw(self.image, self.x, self.y,self.angle,.7,.7,self.origin_x, self.origin_y)
    --love.graphics.print(self.angle, 100, 150)
    
end
