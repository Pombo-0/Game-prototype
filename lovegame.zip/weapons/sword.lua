Sword = Object:extend()
local espada1 = love.graphics.newImage("images/sword.png")
local espada2 = love.graphics.newImage("images/sword.png")
local espada3 = love.graphics.newImage("images/sword.png")

function Sword:new(target, tipo, user)
    self.alpha = 1
    self.target = target
    self.x = self.target.x
    self.y = self.target.y
    self.tipo = tipo
    if tipo == 1 then
        self.image = espada1
    elseif tipo == 2 then
        self.image = espada2
    elseif tipo == 3 then
        self.image = espada3
    end
    self.slash = {
        width = slash:getWidth(),
        height = slash:getHeight()
    }
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    
    self.origin_x=0
    self.origin_y=0

    --self.origin_x=target.x-40
    --self.origin_y=target.y-40
    
    --self.origin_x=target.origin_x-40 -- -20--self.width/2 - 30
    --self.origin_y=target.origin_y+10--12.5--self.height/2 - 8
    if user == nil then
        self.user = "enemy"
    else
        self.user = "player"
    end 
    
    self.attacking = 0
    
    self.HITBOX = HC.rectangle(self.x, self.y, 60, 50)
    
end 

function Sword:update(dt)
    self.x = self.target.x
    self.y = self.target.y
    self.slash.x = self.x
    self.slash.y = self.y
    self.angle = self.target.angle
    self.slash.angle = self.angle
   
    if self.attacking == 0 then
        if self.tipo==1 then
        self.image = espada1
        self.slash.width,self.slash.height=0.35,0.35
        --self.HITBOX.w,self.HITBOX.h=20, 20
        --self.HITBOX = HC.rectangle(self.x, self.y, 60, 50)
        elseif self.tipo==2 then
        self.image = espada2
        self.slash.width,self.slash.height=0.40,0.40
        self.HITBOX.width,self.HITBOX.height=30, 30
        elseif self.tipo==3 then
        self.image = espada3
        self.slash.width,self.slash.height=0.45,0.45
        self.HITBOX.width,self.HITBOX.height=40, 40
        end
        self.alpha = 1
        self.angle = self.target.angle
        self.origin_x=-5 --self.target.origin_x-40
    elseif self.attacking == 1 then
        self.alpha = self.alpha-2*dt
        self.angle = self.target.angle - meialua
        --self.origin_x=5 --self.target.origin_x+65
    end
    
    self.HITBOX:setRotation(self.target.angle)
    self.HITBOX:moveTo(self.x+40*math.cos(self.target.angle), self.y+40*math.sin(self.target.angle))
    
end

function Sword:draw()
    --self.HITBOX:draw('fill')
    
    if self.attacking == 1 then
    love.graphics.setColor(1,0,0,self.alpha)
    love.graphics.draw(slash, self.x, self.y,self.target.angle,self.slash.width,self.slash.height, 0, 100)--,self.origin_x, self.origin_y)
    --love.graphics.print(self.alpha, 200, 300)
    love.graphics.setColor(1,1,1,1)
    end
    love.graphics.draw(self.image, self.x, self.y,self.angle,3,3,self.origin_x, self.origin_y)
    --lgp(self.x, self.x + 50, self.y + 34)
    --love.graphics.setColor(1,1,1, 0.5)
    --love.graphics.setColor(1,1,1,1)
    
    
--------------------!!∆∆∆∆
--------HITBOX------!!∆∆∆∆∆∆∆
--------------------!!∆∆∆∆∆∆∆∆∆∆
    --self.hitbox:draw('fill')
    --love.graphics.print(self.angle, 100, 150)
end