Shield = Object:extend()

function Shield:new(target, tipo)
    self.target = target
    if tipo == 1 then
        self.image = love.graphics.newImage("images/shield.png")
        
    elseif tipo == 2 then
        self.image = love.graphics.newImage("images/shield.png")
        
    end
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    self.origin_x=target.origin_x-15 -- -20--self.width/2 - 30
    self.origin_y =target.origin_y+7.5 --12.5--self.height/2 - 8
    
    
end

function Shield:update(dt)
    self.x = self.target.x
    self.y = self.target.y
    self.angle = self.target.angle
    
    
end

function Shield:draw()
    love.graphics.draw(self.image, self.x, self.y,self.angle,.5,-.5,self.origin_x, self.origin_y)
    --love.graphics.print(self.angle, 100, 150)
    
end