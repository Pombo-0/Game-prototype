Hammer = Object:extend()

function Hammer:new(target)
    self.target = target
    self.image = love.graphics.newImage("images/hammer.png")
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    self.origin_x = -5
    self.origin_y = 5
    
    self.attacking = 0
end

function Hammer:update(dt)
    self.x = self.target.x
    self.y = self.target.y
    self.angle = self.target.angle
    
    if self.attacking == 0 then
        self.image = love.graphics.newImage("images/hammer.png")
        self.r = 0
        
        self.alpha = 1
        self.angle = self.target.angle+pii/4
        --self.origin_x=0--self.target.origin_x-40
    elseif self.attacking == 1 then
        self.alpha = self.alpha-1.5*dt
        self.r=self.r+280*dt
        self.angle = self.target.angle
        --15--self.target.origin_x+65
    end
end

function Hammer:draw()
    if self.attacking == 1 then
        love.graphics.setColor(1,0,0,self.alpha)
        love.graphics.circle("fill", self.x, self.y, self.r)
        love.graphics.setColor(1,1,1,1)
        end
    love.graphics.draw(self.image, self.x, self.y,self.angle,3,3,self.origin_x, self.origin_y)
    love.graphics.print(self.alpha, 100, 150)
    
end
