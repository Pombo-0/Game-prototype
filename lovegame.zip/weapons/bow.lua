Bow = Object:extend()
local bow = love.graphics.newImage("images/bow.png")
local bowarrow = love.graphics.newImage("images/bowarrow.png")

function Bow:new(target)
    self.target=target
    self.image=bow
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    self.origin_x=-2--target.origin_x--self.width / 2 -25
    self.origin_y=12--target.origin_y+5--self.height / 2 +30
    self.angle = 0
    
    self.lastoriginx=target.origin_x
    self.lastoriginy=target.origin_y
    
    self.attacking = 0
    
end

function Bow:update(dt)
    self.x = self.target.x--+20*math.cos(self.angle)
    self.y = self.target.y---10*math.cos(self.angle)
    
    
    if self.attacking == 0 then
        self.image = bow
        self.angle = self.target.angle+1.2
        --self.target.origin_y+5
        --self.angle = self.target.angle --+meialua
    elseif self.attacking == 1 then
        self.image = bowarrow
        self.angle = self.target.angle+pii/4
        --self.origin_y=15--self.lastoriginy+55
        
    end
end

function Bow:draw()
    love.graphics.draw(self.image, self.x, self.y, self.angle,3,3,self.origin_x, self.origin_y)
    
end