Axe = Object:extend()
axeProject = Object:extend()

local axe1 = love.graphics.newImage("images/axe.png")
local axe2 = love.graphics.newImage("images/axe.png")
local axe3 = love.graphics.newImage("images/axe.png")
local axe4 = love.graphics.newImage("images/axe.png")

function Axe:new(target, tipo)
    self.target = target
    self.tipo = tipo
    if tipo == 1 then
        self.image = axe1
    elseif tipo == 2 then
        self.image = axe2
    elseif tipo == 3 then
        self.image = axe3
    elseif tipo == 4 then
        self.image = axe4
    end
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    self.origin_x=0--self.target.origin_x-20 
    self.origin_y=0--self.target.origin_y+2.5
    self.attacking=0
    self.shooting=0
end

function Axe:update(dt)
    
    self.x = self.target.x
    self.y = self.target.y
    self.angle = self.target.angle
    
    if self.attacking == 0 then
        if self.tipo==1 then
        self.image = axe1
        self.slash_w,self.slash_h=0.35,0.35
        elseif self.tipo==2 then
        self.image = axe2
        self.slash_w,self.slash_h=0.40,0.40
        elseif self.tipo==3 then
        self.image = axe3
        self.slash_w,self.slash_h=0.45,0.45
        elseif self.tipo==4 then
        self.image = axe4
        self.slash_w,self.slash_h=0.50,0.50
        end
        self.alpha = 1
        self.angle = self.target.angle
        self.origin_x=-5 --self.target.origin_x-40
    elseif self.attacking == 1 then
        self.alpha = self.alpha-2*dt
        self.angle = self.target.angle - meialua
        --self.origin_x=self.target.origin_x+65
    end
    
end

function Axe:draw()
    
if self.attacking == 1 then
    love.graphics.setColor(1,0,0,self.alpha)
    love.graphics.draw(slash, self.x, self.y,self.target.angle,self.slash_w,self.slash_h, 0, 100)
    love.graphics.setColor(1,1,1,1)
    end
    love.graphics.draw(self.image, self.x, self.y,self.angle, 3, 3,self.origin_x,self.origin_y)
end



------------------------
--AXEPROJECT
------------------------

function axeProject:new(target, spd)
    self.target = target
    self.x = target.x
    self.y = target.y
    self.speed = spd
    if self.target.isEnemy then
        if target.weapon.tipo == 1 then
            self.image = axe1
        elseif target.weapon.tipo == 2 then
            self.image = axe2
        elseif target.weapon.tipo == 3 then
            self.image = axe3
        elseif target.weapon.tipo == 4 then
            self.image = axe4
        end
    else
        if target.weapon[1].tipo == 1 then
            self.image = axe1
        elseif target.weapon[1].tipo == 2 then
            self.image = axe2
        elseif target.weapon[1].tipo == 3 then
            self.image = axe3
        elseif target.weapon[1].tipo == 4 then
            self.image = axe4
        end
    end
    self.angle = self.target.angle
    self.cos = math.cos(self.angle)
    self.sin = math.sin(self.angle)
    
end

function axeProject:update(dt)
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    
    self.origin_x = self.width / 2
    self.origin_y = self.height / 2
    
    self.x=self.x+self.speed*self.cos*dt
    self.y=self.y+self.speed*self.sin*dt
    
    self.angle = self.angle + (meialua*6) * dt
    
end

function axeProject:draw()
    love.graphics.draw(self.image, self.x, self.y, self.angle, 3, 3, self.origin_x, self.origin_y)
end