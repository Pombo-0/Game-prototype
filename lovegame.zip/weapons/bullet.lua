Bullet = Object:extend()

function Bullet:new(x, y, spd)
    --self.image = love.graphics.newImage("Imagens/bullet-blue.png")
    self.x = x
    self.y = y
    self.speed = spd
    self.width = 20
    self.height = 8
    
    self.angle = p.angle
    
    --if rodar == 0 then
        --self.curso = "down"
        --self.angle = meialua
    --elseif rodar == 1 then
    --    self.curso = "right"
      --  self.angle = meialua * 2
    --elseif rodar == 2 then
      --  self.curso = "up"
        --self.angle = -meialua
    --elseif rodar == 3 then
      --  self.curso = "left"
        --self.angle = meialua * 4
--    end
    
    
end

function Bullet:update(dt)
    
    
    --self.origin_x = self.image:getWidth() / 2

    --self.origin_y = self.image:getHeight() / 2
    
    if self.angle == 270 then
        self.y = self.y + self.speed * dt
    elseif self.angle == 180 then
        self.x = self.x - self.speed * dt
    elseif self.angle == 90 then
        self.y = self.y - self.speed * dt
    elseif self.angle == 0 then
        self.x = self.x + self.speed * dt
    end
    
    
end

function Bullet:draw()
    love.graphics.rect("fill", self.x, self.y, self.angle, 1, 1, self.origin_x, self.origin_y)
    love.graphics.print(self.x, 400, 400)
end

function Bullet:checkCollision(obj)
    local self_left = self.x
    local self_right = self.x + self.width
    local self_top = self.y
    local self_bottom = self.y + self.height

    local obj_left = obj.x
    local obj_right = obj.x + obj.width
    local obj_top = obj.y
    local obj_bottom = obj.y + obj.height

    if  self_right > obj_left
    and self_left < obj_right
    and self_bottom > obj_top
    and self_top < obj_bottom then
        self.dead = true
    end
    
end

function Bullet:tocaParede()
    
    if self.x < window_limitx - 100 or self.x > window_width + 100 or self.y < window_limity - 100 or self.y > window_height + 100 then
        self.dead = true
    end
    
    
end