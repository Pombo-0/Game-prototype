Arrow = Object:extend()


function Arrow:new(target, spd, user)
    self.image = love.graphics.newImage("images/arrow.png")
    self.target = target
    self.x = target.x
    self.y = target.y
    self.speed = spd
    
    self.angle = target.angle
    
    self.cos = math.cos(self.angle)
    self.sin = math.sin(self.angle)
    
    self.HITBOX = HC.rectangle(self.x, self.y, 30, 10)
    
end

function Arrow:update(dt)
    tocaParede(self)
    
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    
    self.origin_x = self.width / 2
    self.origin_y = self.height / 2
    
    self.x=self.x+self.speed*self.cos*dt
    self.y=self.y+self.speed*self.sin*dt 
    self.HITBOX:moveTo(self.x, self.y)
    self.HITBOX:setRotation(self.angle)
    
end

function Arrow:draw()
    
        --love.graphics.print("EU REALMENTE TO VIVO", self.target.x, self.target.y + 50)
    love.graphics.draw(self.image, self.x, self.y, self.angle+pii/4, 3, 3, self.origin_x, self.origin_y)
    --self.HITBOX:draw('fill')
end