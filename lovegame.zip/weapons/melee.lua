Melee = Object:extend()

function Melee:new()
    self.slash = {
        image = love.graphics.newImage("images/slash.png"),
        width = image:getWidth()*1.5,
        height = image:getHeight()*1.5
    }
end