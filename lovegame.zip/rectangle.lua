class "Rectangle" "Polygon" {
	new = function(self,topLeft,size)
		local mt = getmetatable(self)
		function mt:__tostring()
			return "Rect:TopLeft:"..self.topLeft.."Size:"..self.size
		end
		self.verticies = {
			topLeft,
			topLeft + new "Vector2" (size.x,0),
			topLeft + new "Vector2" (size.x,size.y),
			topLeft + new "Vector2" (0,size.y)
		}
		self.mainPoint = topLeft
	end
}