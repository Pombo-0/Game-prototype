Object = require "classic"
Camera = require "Camera"
sti = require "sti"
tick = require "tick"
HC = require "HC"
--require "gooi"
--require "component"
--require "joy"

require "weapons/melee"
require "weapons/shield"
require "weapons/sword"
require "weapons/bow"
require "weapons/axe"
require "weapons/hammer"
require "weapons/staff"
require "weapons/arrow"
require "items/potion"

require "player"
require "enemy"
require "hands"

require "toque"
require "botao"
require "joystick"


function love.load()
    love.window.setMode(0,0, {highdpi = true})
    
    fs = 2
    ps = love.window.getDPIScale()
    
    love.graphics.setDefaultFilter( "nearest" )
    myFont = love.graphics.newFont( "arial.ttf", 6*fs )
    myFont:setFilter( "nearest", "nearest" )
    love.graphics.setFont(myFont)
    
    
    pii = math.pi
    hb, wb = 60, 60
    
    left = Botao(200, 140, hb, wb)
    right = Botao(300, 140, hb, wb)
    up = Botao(245, 90, hb, wb)
    down = Botao(245, 190, hb, wb)
    bshoot = Botao(700, 240, hb, wb)
    change = Botao(700, 180, hb-10, wb-10)
    
    
    meialua = math.pi/2
    window_width = 900 --887*3
    window_height = 900 --455*3
    window_limitx = 0 --40
    window_limity = 0 --67
    slash = love.graphics.newImage("images/slash.png")
    camera = Camera()
    gameMap = sti("export.lua")
    joystick = Joystick()
    player = Player()
    --cor, velocidade, alvo, x, y, arma, tipo, escudo, velocidade do circulo, alcance
    enemyList = {}
    potionList = {}
    weaponList = {
        "sword",
        "bow" ,
        "sword"
    }
    XP = 0
    kills = 0
    time = 0 
    phaseTime = 10
    phase = 1
    --tempo = 0
    appearTime = 0
    quantity = 4
    canTouch = true 
    rand = 0
    --quant = 1
    --starrt = 
    
    --killGoal = 0
    killGoal = {2, 5, 9, 13, 18, 23, 28, 33, 40, 48, 56, 64, 74, 85, 97, 107, 117, 127}
    killGoal_actual = 0
    alive = true 
    phaseAlpha = 3
    
    --table.insert(enemyList, Enemy(love.math.random(0, 1000), love.math.random(0, 1000), love.math.random(30, 140), love.math.random(900000, 3100000), weaponList[love.math.random(1, 2)], player))
---------------------------------------
end

function love.update(dt)
--------------------------------------
    --if false then 
    --for i=0, 5 do 
    windowIncrease = 20
    appearTime = appearTime + dt
    if true and appearTime >= 1 and #enemyList < quantity then 
        appearTime = 0
        table.insert(enemyList, Enemy(love.math.random(0, 1000), love.math.random(0, 1000), love.math.random(30, 140), love.math.random(90, 310), weaponList[love.math.random(1, 3)], player))
    end
    
    
    if alive then 
        time = time + dt 
        phaseTime = phaseTime - dt
    end 
    
    if phaseTime <= 0 then 
        phaseTime = 10 
        phase = phase + 1
        phaseText = true 
        
        quantity = quantity + 1
        window_width = window_width + windowIncrease
        window_height = window_height + windowIncrease
        window_limitx = window_limitx - windowIncrease
        window_limity= window_limity - windowIncrease
    end 
    
    for i=1, #killGoal do 
        if time >= 10*i and kills < killGoal[i] then 
            player.hp = 0
        end
    end
    
    killGoal_actual = killGoal[phase]
    
    
    --love.timer.sleep(0.01)
    --love.window.setVSync(1)
    camera:update(dt)
    camera:follow(player.x, player.y)
    player:update(dt)
    for i,v in ipairs(enemyList) do
        v:update(dt)
        if v.hp <=0 then 
            table.remove(enemyList, i)
            XP = XP + 100 
            kills = kills + 1
            
            rand = love.math.random(1, 4)
            if rand ~= 1 then 
                table.insert(potionList, Potion("health", v.x, v.y))
            end
        end
    end 
    
    for i,v in ipairs(potionList) do
        v:update(dt)
    end 
    
    if player.hp <= 0 then 
        player.hp = 0
        canTouch = false 
        alive = false 
        deathSound:play()
        tick.delay(function () 
            love.event.quit("restart")
            end, 1.3)
    end 
    
    tick.update(dt)
    
    --if #listOfArrows > 1 then
    --table.remove(listOfArrows, 2)
    --end
    --gameMap:update(dt)
    
    
    toque_update(dt)
    joystick:update(dt)
    --gooi:update(dt)
---------------------------------------
end

function love.draw()
    camera:attach()
---------------------------------------
    
    --gooi:draw()
    --love.graphics.setDefaultFilter("nearest", "nearest")
    
    if player.hp > 0 then 
        player:draw() 
    end 
    
    for i,v in ipairs(enemyList) do
        v:draw()
    end 
    for i,v in ipairs(potionList) do
        v:draw()
    end 
    
    --love.graphics.print(player.angle, 100, 200)
    --love.graphics.print(enemyList[1].hands.right.x, 100, 300)
    love.graphics.print("FPS: " .. love.timer.getFPS(), player.x, player.y-160)
    --lgp("ignore me im just a text", 200, 200)
    --lgp(tostring(checkCollision(player, enemyList[1].weapon.slash)), player.x + 35, player.y + 35)
    
if false then
    lgp("player x: "..player.x, player.x -70, player.y + 60)
    lgp("player y: "..player.y, player.x -70, player.y + 80)
end 

    
    --toque_draw()
    
----ENEMYLIST ITERATION!!!!----
    for i, v in ipairs (enemyList) do
        lgp("HP: "..enemyList[i].hp, v.x, v.y - 15, 0, 2, 2)
        if false then
        lgp ("isDamaged: "..v.isDamaged, v.x, v.y + 25, 0, 2, 2)
        lgp ("color 2: "..v.color[2], v.x, v.y + 45, 0, 2,2)
        lgp ("color 3: "..v.color[3], v.x, v.y + 65, 0, 2,2)
        end
        
    end
    love.graphics.rectangle("line", window_limitx, window_limity, window_width, window_height)
    
---------------------------------------
    camera:detach()
    camera:draw()
    
if false then
    love.graphics.print("angulo: "..joystick.angle, 580, 80)
    love.graphics.print("distance x: "..distancex, 580, 100)
    love.graphics.print("distance y: "..distancey, 580, 120)
    love.graphics.print("distance TOTAL: "..distancej, 580, 140)
    love.graphics.print("centerx: "..centerx, 580, 160)
    love.graphics.print("centery: "..centery, 580, 180)
    lgp(sera, 580, 200)
    
    

    lgp("player x: "..player.x, 580, 220)
    lgp("player y: "..player.y, 580, 240)
    end -- end if false 
    
if false then
    left:draw()
    right:draw()
    up:draw()
    down:draw()
end
    bshoot:draw()
    change:draw()
    
    joystick:draw()
    local maxHpRect = 150
    if player.hp >= 150 and player.hp <= 240 then 
        maxHpRect = player.hp
    elseif player.hp < 150 then 
        maxHpRect = 150
    end 
    
    
    love.graphics.setColor(1,0,0)
    love.graphics.rectangle("fill", 50, 50, player.hp, 25)
    love.graphics.setColor(1,1,1)
    love.graphics.rectangle("line", 50, 50, maxHpRect, 25)
    lgp("HP: "..player.hp, 50, 50, 0, 2, 2)
    
    
    
    if false then
    lgp("hitbox angle: "..player.HITBOX:rotation(), 380, 300)
    lgp("player immunity: "..player.immunity, 380, 320)
    lgp("player damaged: "..playerDamaged, 380, 340)
    lgp("player DAMAGING: "..tostring(player.isDamaging), 380, 360)
    lgp("XP: "..XP, 280, 320)
    lgp("rand: "..rand, 280, 340)
    end --end if false
    lgp("Mortes: "..kills, 280, 360, 0, 3, 3)
    lgp("Tempo total: "..time , 450, 67, 0, 1.5, 1.5)
    lgp("Meta: "..killGoal[phase].." mortes \nFaltam "..math.ceil(phaseTime).." segundos", 450, 87, 0, 2, 2)
    if false then 
    if phase ~= 1 then
        lgp("Mate ".. killGoal[phase] - killGoal[phase-1].." inimigos em "..phaseTime.." segundos.", 500, 87, 0, ps/fs, ps/fs) -- 1.5, 1.5)
    else 
        lgp("Mate ".. killGoal[phase].." inimigos em "..phaseTime.." segundos.", 500, 87, 0, 1.5, 1.5)
    end 
    end 
    
    
    if phaseText and alive then
        if phaseAlpha > 0 then
        phaseAlpha = phaseAlpha - 0.1
        love.graphics.setColor(1,1,1, phaseAlpha)
        lgp("Nível "..phase, 350, 200, 0, 5, 5)
        love.graphics.setColor(1,1,1)
        else 
            phaseAlpha = 3
            phaseText = false
        end
    end 
    
    
    --lgp("tempo: ".. tempo, 280, 380)
    --lgp("love timer: ".. love.timer.getTime(), 280, 380)
    
    if playerDamaged == 1 and player.immunity < 1 then 
        love.graphics.setColor(1,0,0, player.alpha)
        love.graphics.rectangle ("fill", 0, 0, 1000, 1000)
        love.graphics.setColor(1, 1, 1, 1) 
    end 
    --! LOVE.DRAW() END::::
end



function love.keypressed(key)
    player:keyPressed(key)
    if key == "1" then
    love.graphics.setBackgroundColor(0.019, 0.54, 1)
    elseif key == "2" then
    love.graphics.setBackgroundColor(1,1,1)
    elseif key == "3" then
    love.graphics.setBackgroundColor(0, 0, 0)
end
end

function love.keyreleased(key)
    player:keyReleased(key)
end

function checkCollision(a, b)
    local a_left = a.x
    local a_right = a.x + a.width
    local a_top = a.y
    local a_bottom = a.y + a.height

    local b_left = b.x
    local b_right = b.x + b.width
    local b_top = b.y
    local b_bottom = b.y + b.height
    
    return  a_right > b_left
        or a_left < b_right
        or a_bottom > b_top
        or a_top < b_bottom
end

function checkCollision2(a, b)
    local player_left = a.x
    local player_right = a.x + a.width
    local player_top = a.y
    local player_bottom = a.y + a.height

    local obj_left = b.x
    local obj_right = b.x + b.width
    local obj_top = b.y
    local obj_bottom = b.y + b.height

    if  player_right > obj_left
    and player_left < obj_right
    and player_bottom > obj_top
    and player_top < obj_bottom then
        a.dead = true
    end
end

function tocaParede(a)
    if a.x < window_limitx - 100 or a.x > window_width + 100 or a.y < window_limity - 100 or a.y > window_height + 100 then
        a.dead = true
    else
        a.dead = false
    end
end

function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

--round( 1.238345, 2 ) -- gives 1.24


function getDistance(x1, y1, x2, y2)
    local horizontal_distance = x1 - x2
    local vertical_distance = y1 - y2
    
    local a = horizontal_distance ^2
    local b = vertical_distance ^2
    
    local c = a + b
    local distance = math.sqrt(c)
    return distance
end




function REPOSITOOOORIO()
    if starrt == 0 then 
        starrt = 1
     table.insert(enemyList, Enemy(love.math.random(0, 1000), love.math.random(0, 1000), love.math.random(30, 60), love.math.random(100, 300), weaponList[love.math.random(1, 2)], player))
    end
    if false then
        tempo = tempo+dt
        if tempo >= (5*quant) then 
            tempo = 0
            for i=1, quant*2 do 
            tick.delay(function ()
                table.insert(enemyList, Enemy(love.math.random(0, 1000), love.math.random(0, 1000), love.math.random(30, 60), love.math.random(100, 300), weaponList[love.math.random(1, 2)], player))
                
            end, 1)
            end 
            quant = quant + 1
        end
    end 
    --end
    --end 
    
    if false then
    for i=0, 5 do 
        tick.delay(
            function ()
                table.insert(enemyList, Enemy(100*i, 100, 20, 100, "bow", player))
            end, 2)
    end 
    end 
    
    
    
        if false then 
    if time <= 10 then 
        killGoal = 2
    end 
    if time <= 20 then 
        killGoal = 5
    end
    if time <= 30 then 
        killGoal = 9
    end 
    if time <= 40 then 
        killGoal = 13
    end
    if time <= 50 then 
        killGoal = 18
    end 
    if time <= 60 then 
        killGoal = 23
    end
    
    if kills < killGoal then 
        player.hp = 0 
    end 
    
    if false then 
    if (time >= 10 and kills < 2) or (time >= 20 and kills < 5) or (time >= 30 and kills < 9) or (time >= 40 and kills < 13) or (time >= 50 and kills < 18) or (time >= 60 and kills < 23) then
        player.hp = 0 
    end 
    end 
    end 
end 
