Enemy = Object:extend()
local cos
local sin

boneSounds = {
    love.audio.newSource("sounds/bone1.mp3", "static"), 
    love.audio.newSource("sounds/bone2.mp3", "static"), 
    love.audio.newSource("sounds/bone3.mp3", "static"), 
    love.audio.newSource("sounds/bone4.mp3", "static")
}

function Enemy:new(x, y, spd, hp, weapon, target, shield, vel, range)
    --self.hands = Hands(color, self)
    if color~=nil and spd~=nil and target~=nil and x~=nil and y~=nil and weapon~=nil and tipo~=nil then
    self.angle = meialua
    self.x = x
    self.y = y
    self.speed = spd
    self.hp = hp
    self.target = target
   
    self.vel = vel
    self.range = range
    self.ammo = 1
    self.isEnemy = true
    
    self.project = {}
    self.image = love.graphics.newImage("images/skeleton.png") 
    
    if vel==nil then self.vel=135 end
    if range==nil then self.range=300 end
    elseif color==nil and spd==nil and target==nil and x==nil and y==nil and weapon==nil then
        
        local armas={"sword", "bow", "axe"}
        --local cores={"red","green","purple","yellow"}
        --color=cores[love.math.random(1, #cores)]
        spd=player.speed/4
        target=player
        x=love.math.random(0, window_width)
        y=love.math.random(0, window_height)
        weapon=armas[love.math.random(1, #armas)]
        tipo=1
    end
   
   
    if weapon == "sword" then
        self.WEAPON = "sword"
        self.weapon=Sword(self, tipo)
    elseif weapon == "bow" then 
        self.WEAPON="bow"
        self.weapon=Bow(self) 
    elseif weapon == "axe" then 
        self.WEAPON="axe"
        self.weapon=Axe(self, tipo)
    elseif weapon == "hammer" then 
        self.WEAPON="hammer"
        self.weapon=Hammer(self)
    elseif weapon == "staff" then 
        self.WEAPON="staff"
        self.weapon=Staff(self)
    end
    
    if shield == 1 then
        self.SHIELD = true
        self.shield = Shield(self, 1)
    else
        self.SHIELD = false 
    end 
        
    
    self.width = self.image:getWidth()
    self.height = self.image:getHeight()
    self.origin_x = self.width / 2
    self.origin_y = self.height / 2
    self.distance1 = getDistance(self.x, self.y, self.target.x, self.target.y)
    
    if weapon == "sword" then 
        self.weapon.HITBOX = HC.rectangle(self.x, self.y, 30, 40)
    elseif weapon == "bow" then 
        --self.weapon.HITBOX = HC.rectangle(self.x, self.y, 10, 30)
    end
    
    self.HITBOX = HC.rectangle(self.x, self.y, 30, 40)
    self.color = {1, 1, 1}
    
    self.animTime = 0
    self.animSpeed = 12
    self.isDamaged = 0
    --! FUNCTION END
end

function Enemy:update(dt)
    self.HITBOX:moveTo(self.x, self.y) 
    
    if self.WEAPON == "sword" then
        self.weapon.HITBOX:moveTo(self.x, self.y)
    end
    
    self.angle = math.atan2(self.target.y - self.y, self.target.x - self.x)
    cos = math.cos(self.angle)
    sin = math.sin(self.angle)
    
    self.distance1 = getDistance(self.x, self.y, self.target.x, self.target.y)
    if self.distance1 < self.range and self.WEAPON == "bow" then
        --if self.speed>0 then
        self.x = self.x - (self.speed/3) * cos * (self.distance1/self.vel) * dt
        self.y = self.y - (self.speed/3) * sin * (self.distance1/self.vel) * dt
    else
        self.x = self.x + self.speed * cos * (self.distance1/self.vel) * dt
        self.y = self.y + self.speed * sin * (self.distance1/self.vel) * dt
    end
    if self.WEAPON=="sword" then
        if self.distance1 < 100 then
            if self.weapon.attacking==0 then 
            tick.delay(function ()
                self.weapon.attacking=1
                
                end, 0.75)
            :after(function () self.weapon.attacking=0 end, 0.75)
            tick.delay(
                    function ()
                        self.isDamaging = true
                    end, 0.75)
            :after (function ()
                        self.isDamaging = false
                        end, 0.05)
            end
        end
    elseif self.WEAPON=="bow" then
        --if self.distance1 < self.range then
            if self.weapon.attacking==0 then
                tick.delay(function ()
                    self.weapon.attacking=1
                    self.ammo = 1
                end, 1)
                :after(function ()
                    if self.weapon.attacking == 1 then
                    self.weapon.attacking=0
                    if self.ammo == 1 then
                        self.ammo=0
                        --if #self.project==0 then
                        table.insert(self.project, Arrow(self, 100))
                        --tick.delay(function()
                            --table.remove(self.project, 1) end , 1.25)
                        --end 
                        
                    end
                    end
                    
                    end, 1) --MUDAR PRA 1
            end
        --end
    elseif self.WEAPON=="hammer" then
        if self.distance1 < 275 then
            if self.weapon.attacking==0 then
            tick.delay(function ()
                self.weapon.attacking=1
                end, 0.8)
            :after(function () self.weapon.attacking=0 end, 0.8)
            end
        end
    elseif self.WEAPON=="axe" then
        if self.distance1 < 110 then
            if self.weapon.attacking==0 then
            tick.delay(function ()
                self.weapon.attacking=1
                end, 0.25)
            :after(function () self.weapon.attacking=0 end, 0.5)
            end
        elseif self.distance1 < self.range then
            if self.weapon.shooting==0 then
                tick.delay(function ()
                self.weapon.shooting=1
                self.weapon.attacking=1
                self.ammo = 1 end, 0.5)
            :after(function ()
                    if self.weapon.shooting == 1 then
                    self.weapon.shooting=0
                    self.weapon.attacking=0
                    if self.ammo == 1 then
                        self.ammo=0
                        if #self.project==0 then
                        table.insert(self.project, axeProject(self, 500))
                        tick.delay(function()
                            table.remove(self.project, 1) end, 1.25)
                        end
                    end
                end
            
                    end, 0.75)
            end
        end
        
    end
    
    for j,w in ipairs (self.project) do
        self.project[j]:update(dt)
            if w.dead then 
                table.remove(self.project, j)
            end
    end 
    
    
    if (player.WEAPON=="sword" and player.weapon[1].HITBOX:collidesWith(self.HITBOX) and player.isDamaging) then
        self.isDamaged = 1
        self.color = {1, 0, 0}
        self.hp = self.hp - 100 
        boneSounds[math.random(1,4)]:play()
    end
    
    for i, v in ipairs(player.project) do
        if self.HITBOX:collidesWith(v.HITBOX) then 
            self.hp = self.hp - 75
            table.remove(player.project, i)
            
        end
    end 
    if false and self.isDamaged == 1 then 
        tick.delay (function ()
            boneSounds[1]:play()
        end, 0.001)
       :after (function () end, 2)
    end
    
    
    self.weapon:update(dt)
    if self.SHIELD == true then
        self.shield:update(dt)
    end
    
    if self.isDamaged == 1 then
        self.color[2] = self.color[2] + dt--*3
        self.color[3] = self.color[3] + dt--*3
        animationDamage(self, dt)
        
        tick.delay(function() 
            self.color = {1,1,1}
            self.isDamaged = 0
            end, 0.45)
    end
    
   
    
    if false and (self.color[2] >= 1 or self.color[3] >= 1) then
        --self.color[2] = 1
        --self.color[3] = 1
        self.color = {1,1,1}
        tick.delay(function() 
            self.isDamaged = 0
        end, 0.3)
    end 
    
    ---WINDOW COLLISION
    if true then 
    if self.x < window_limitx then
        self.x = window_limitx
    elseif self.x + self.width > window_width then
       self.x = window_width - self.width
    end
    if self.y < window_limitx then
      self.y = window_limitx
    elseif self.y + self.height > window_height then
       self.y = window_height - self.height
    end 
    end 
    --! FUNCTION END::
end

function Enemy:draw()
    --lgp ("isDamaged: "..self.isDamaged, self.x+10,self.y+10)
    love.graphics.setColor(self.color)
    love.graphics.draw(self.image, self.x, self.y, self.alpha, 4, 4, self.origin_x, self.origin_y)
    love.graphics.setColor(1, 1, 1)
    
    --player.weapon.HITBOX:draw('fill')
    if (self.WEAPON == "sword") or (self.WEAPON == "bow" and #self.project > 0) then
        --self.weapon.HITBOX:draw("line") 
    end
    
    for j,w in ipairs(self.project) do
        self.project[j]:draw()
    end 
    
    
    --love.graphics.line(self.x, self.y, self.target.x, self.target.y)
    --love.graphics.line(self.x, self.y, self.target.x, self.y)
    --love.graphics.line(self.target.x, self.target.y, self.target.x, self.y)

    self.distance2 = getDistance(self.x, self.y, self.target.x, self.target.y)
    --love.graphics.circle("line", self.x, self.y, self.distance2)
    --love.graphics.print(self.x, 100, 100)
    --love.graphics.print(self.y, 100, 125)
    
    self.weapon:draw()
    if self.SHIELD then
        self.shield:draw() 
    end 
    
    --self.HITBOX:draw('line')
end


function animationDamage(a, dt)
    --a.animTime = {0}
    --a.animSpeed = 10
    
    a.animTime = a.animTime + dt 
    a.animSpeed = a.animSpeed - 5*dt
    
    --if #animTime ~= 0 then
        if a.animTime <= 0.3 then
            a.x = a.x - a.animSpeed*math.cos(a.angle)
            a.y = a.y - a.animSpeed*math.sin(a.angle)
        else 
            a.animSpeed = 12
            a.animTime = 0
            --table.remove(animTime, 1)
        end
    --end 
    
end